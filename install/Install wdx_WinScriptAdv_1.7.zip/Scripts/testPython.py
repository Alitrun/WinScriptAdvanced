# Script for WinScriptAdv content plugin
# Python script test 

fp = open(filename, encoding="utf-8")
content = fp.readline()
fp.close()